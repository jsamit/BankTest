﻿namespace BankTestAPI.Service
{
    public class UserService
    {

    }
}
