﻿using BankTestAPI.DTO;

namespace BankTestAPI.Contracts
{
    public interface IUserTransactionService
    {
        public bool Deposit(Guid userId,TransactionDTO transactionDTO);
        public bool WithDraw(Guid userId, TransactionDTO transactionDTO);
    }
}
