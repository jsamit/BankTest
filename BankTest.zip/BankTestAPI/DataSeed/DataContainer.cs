﻿using BankTestAPI.Entities;

namespace BankTestAPI.DataSeed
{
    public class DataContainer
    {
        public static List<UserEO> userEOs = new List<UserEO>
        {
            new UserEO
            {
                Id = new Guid("749ca466-2055-4ce8-9534-6d97a52c380c"),
                Name = "Amit",
                Email = "ersamit007@gmail.com",
                Accounts = new List<AccountEO> {new AccountEO { Id = new Guid("5c91f2ea-dd4d-4090-b11f-85f5ba3e00dd"), Balance = 110 , UserEO = new UserEO { Id = new Guid("749ca466-2055-4ce8-9534-6d97a52c380c") } } }
            }
        };
        public static List<AccountEO> accountsEOs = new List<AccountEO> { userEOs[0].Accounts[0] };
    }
}
