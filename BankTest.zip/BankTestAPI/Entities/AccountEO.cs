﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace BankTestAPI.Entities
{
    public class AccountEO
    {
        public Guid? Id { get; set; }

        public double Balance { get; set; } = default!;
        [JsonIgnore]
        public UserEO? UserEO { get; set; } = default!;
    }
}
