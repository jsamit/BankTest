﻿using BankTestAPI.Contracts;
using BankTestAPI.DataSeed;
using BankTestAPI.Entities;

namespace BankTestAPI.Service
{
    public class AccountService : IAccountService
    {
        public void Create(Guid userId,AccountEO account)
        {
            if(account != null)
            {
                if (account.Balance < 100)
                    throw new Exception("Minimum Balance Required - $100");
                var user = DataContainer.userEOs.FirstOrDefault(x => x.Id == userId);
                if (user != null)
                {
                    account.UserEO = user;
                    account.Id = Guid.NewGuid();
                    DataContainer.accountsEOs.Add(account);
                    user.Accounts.Add(account);
                }
            }
        }

        public void Delete(Guid userId,Guid accountId)
        {
            var account = DataContainer.accountsEOs.Find(x => x.Id == accountId);
            if(account != null && userId == account.UserEO.Id)
                DataContainer.accountsEOs.Remove(account);
        }
    }
}
