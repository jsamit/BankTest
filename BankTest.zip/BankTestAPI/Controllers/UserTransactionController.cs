﻿using BankTestAPI.Contracts;
using BankTestAPI.DTO;
using Microsoft.AspNetCore.Mvc;

namespace BankTestAPI.Controllers
{
    [Controller]
    [Route("api/transaction")]
    public class UserTransactionController : ControllerBase
    {
        private IUserTransactionService userTransactionService;
        public UserTransactionController(IUserTransactionService userTransactionService)
        {
            this.userTransactionService = userTransactionService;
        }
        [HttpPost("deposit/user/{userId}")]
        public IActionResult Deposit(Guid userId,[FromBody] TransactionDTO transactionDTO)
        {
            return Ok(userTransactionService.Deposit(userId, transactionDTO));
        }

        [HttpPost("withdraw/user/{userId}")]
        public IActionResult Withdraw(Guid userId, [FromBody] TransactionDTO transactionDTO)
        {
            return Ok(userTransactionService.WithDraw(userId, transactionDTO)); ;
        }
    }
}
