﻿using System.Text.Json.Serialization;

namespace BankTestAPI.Entities
{
    public class UserEO
    {
        public Guid Id { get; set; } = default!;
        public string Name { get; set; } = default!;
        public string Email { get; set; } = default!;
        [JsonIgnore]
        public List<AccountEO> Accounts { get; set; } = new();

    }
}
