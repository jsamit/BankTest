﻿using BankTestAPI.DTO;
using BankTestAPI.Entities;
using Microsoft.AspNetCore.Mvc.Testing;
using System.Net;
using System.Net.Http.Json;
using Xunit;

namespace BankTest.UT;


public class APITest : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _httpClient;
    private readonly Guid accountId;

    public APITest(WebApplicationFactory<Program> factory)
    {
        _httpClient = factory.CreateClient();
    }

    [Fact]
    public void User_CreateAccount_amount_more_than_100()
    {
 
        var response = _httpClient.PostAsJsonAsync("/api/account/user/749ca466-2055-4ce8-9534-6d97a52c380c",new AccountEO { Balance = 120.00 })?.Result;
        Assert.NotNull(response);
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var content = response.Content.ReadFromJsonAsync<AccountEO>()?.Result;
        Assert.NotNull(content);
        Assert.Equal(120,content.Balance);
    }

    [Fact]
    public void User_CreateAccount_amount_less_than_100()
    {

        var response = _httpClient.PostAsJsonAsync("/api/account/user/749ca466-2055-4ce8-9534-6d97a52c380c", new AccountEO { Balance = 99.00 })?.Result;
        Assert.NotNull(response);
        Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
        var content = response.Content.ReadAsStringAsync()?.Result;
        Assert.Contains("Minimum Balance Required - $100", content);
    }

    [Fact]
    public void User_DeleteAccount()
    {

        var response = _httpClient.DeleteAsync("/api/account/5c91f2ea-dd4d-4090-b11f-85f5ba3e00dd/user/749ca466-2055-4ce8-9534-6d97a52c380c")?.Result;
        Assert.NotNull(response);
        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);

    }

    [Fact]
    public void Transaction_Deposit_less_than_10000()
    {

        var response = _httpClient.PostAsJsonAsync("/api/transaction/deposit/user/749ca466-2055-4ce8-9534-6d97a52c380c", new TransactionDTO(100, new Guid("5c91f2ea-dd4d-4090-b11f-85f5ba3e00dd")))?.Result;
        Assert.NotNull(response);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var content = response.Content.ReadAsStringAsync()?.Result;
        Assert.True(Convert.ToBoolean(content));
    }

    [Fact]
    public void Transaction_Deposit_more_than_10000()
    {

        var response = _httpClient.PostAsJsonAsync("/api/transaction/deposit/user/749ca466-2055-4ce8-9534-6d97a52c380c", new TransactionDTO(10001, new Guid("5c91f2ea-dd4d-4090-b11f-85f5ba3e00dd")))?.Result;
        Assert.NotNull(response);
        Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
        var content = response.Content.ReadAsStringAsync()?.Result;
        Assert.Contains("You can't deposit more than 10,000 at once.", content);
    }

    [Fact]
    public void Transaction_Withdraw_amount_less_than_90_percent()
    {

        var response = _httpClient.PostAsJsonAsync("/api/transaction/withdraw/user/749ca466-2055-4ce8-9534-6d97a52c380c", new TransactionDTO(98, new Guid("5c91f2ea-dd4d-4090-b11f-85f5ba3e00dd")))?.Result;
        Assert.NotNull(response);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var content = response.Content.ReadAsStringAsync()?.Result;
        Assert.True(Convert.ToBoolean(content));
    }

    [Fact]
    public void Transaction_Withdraw_amount_more_than_90_percent()
    {

        var response = _httpClient.PostAsJsonAsync("/api/transaction/withdraw/user/749ca466-2055-4ce8-9534-6d97a52c380c", new TransactionDTO(105, new Guid("5c91f2ea-dd4d-4090-b11f-85f5ba3e00dd")))?.Result;
        Assert.NotNull(response);
        Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
        var content = response.Content.ReadAsStringAsync()?.Result;
        Assert.Contains("You can't withdraw more than the 90% of your balance",content);
    }
}
