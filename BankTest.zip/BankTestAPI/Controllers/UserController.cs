﻿using BankTestAPI.DataSeed;
using Microsoft.AspNetCore.Mvc;

namespace BankTestAPI.Controllers
{
    [Route("api/user")]
    [Controller]
    public class UserController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(DataContainer.userEOs.Take(1));
        }
    }
}
