﻿namespace BankTestAPI.DTO;

public record TransactionDTO(double amount,Guid accountId);
