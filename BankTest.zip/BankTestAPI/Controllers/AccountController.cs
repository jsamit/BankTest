﻿using BankTestAPI.Contracts;
using BankTestAPI.Entities;
using Microsoft.AspNetCore.Mvc;

namespace BankTestAPI.Controllers
{
    [Controller]
    [Route("api/account")]
    public class AccountController : ControllerBase
    {
        private IAccountService accountService;
        public AccountController(IAccountService accountService)
        {
            this.accountService = accountService;
        }

        [HttpPost("user/{id:guid}")]
        public IActionResult Create(Guid id, [FromBody] AccountEO account)
        {
            if(ModelState.IsValid)
            {
                accountService.Create(id, account);
                return Created("/", account);
            }
            return BadRequest(ModelState);
        }

        [HttpDelete("{accountId:guid}/user/{id:guid}")]
        public IActionResult Delete(Guid id, Guid accountId)
        {
            accountService.Delete(id, accountId);
            return NoContent();
        }
    }
}
