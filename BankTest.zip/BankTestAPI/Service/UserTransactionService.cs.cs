﻿using BankTestAPI.Contracts;
using BankTestAPI.DataSeed;
using BankTestAPI.DTO;

namespace BankTestAPI.Service
{
    public class UserTransactionService : IUserTransactionService
    {
        public bool Deposit(Guid userId, TransactionDTO transactionDTO)
        {
            bool result = false;
            if(userId != Guid.Empty && transactionDTO != null && transactionDTO.accountId != Guid.Empty && transactionDTO.amount > 0) 
            {
                if (transactionDTO.amount <= 10000)
                {
                    var user = DataContainer.userEOs.FirstOrDefault(x => x.Id == userId);
                    if (user != null)
                    {
                        if (user.Accounts != null)
                        {
                            var account = user.Accounts.FirstOrDefault(x => x.Id == transactionDTO.accountId);
                            if (account != null)
                            {
                                result = true;
                                account.Balance += transactionDTO.amount;
                            }
                        }
                    }
                }
                else
                    throw new Exception("You can't deposit more than 10,000 at once.");
            }
            return result;
        }

        public bool WithDraw(Guid userId, TransactionDTO transactionDTO)
        {
            bool result = false;
            if (userId != Guid.Empty && transactionDTO != null && transactionDTO.accountId != Guid.Empty && transactionDTO.amount > 0)
            {
                var user = DataContainer.userEOs.FirstOrDefault(x => x.Id == userId);
                if (user != null)
                {
                    if (user.Accounts != null)
                    {
                        var account = user.Accounts.FirstOrDefault(x => x.Id == transactionDTO.accountId);
                        if (account != null)
                        {
                            if (transactionDTO.amount < (account.Balance * 0.90))
                            {
                                account.Balance -= transactionDTO.amount;
                                result = true;
                            }
                            else
                                throw new Exception("You can't withdraw more than the 90% of your balance");
                        }    
                    }
                }
            }
            return result;
        }
    }
}
