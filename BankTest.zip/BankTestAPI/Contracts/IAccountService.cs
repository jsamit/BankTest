﻿using BankTestAPI.Entities;

namespace BankTestAPI.Contracts
{
    public interface IAccountService
    {
        public void Create(Guid userId, AccountEO account);
        public void Delete(Guid userId, Guid accountId);
    }
}
