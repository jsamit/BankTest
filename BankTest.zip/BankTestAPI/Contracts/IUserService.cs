﻿namespace BankTestAPI.Contracts
{
    public interface IUserService
    {

    }
}
